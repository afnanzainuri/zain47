#!/system/xbin/bash
#MauNgapainGblk?
#sayaafnanzainuri
#sayagksuka
#toolskuelurecodebabi
clear
blue='\033[34;1m'
green='\033[32;1m'                                        
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                                           
yellow='\033[33;1m'
sleep 1
toilet -f big -F gay "T00Ls" | lolcat
toilet -f big -F gay "Afnanzainuri" 
echo ""      
echo "\033[32;1mAuthor : Afnanzainuri" 
echo "\033[32;1mTeam : saya solo player"
echo "\033[32;1mKontak Me : 082230884636"
echo "\033[32;1mSubcribe Youtube:"
echo "\033[32;1mNEWBIEHACK" "\033[32;1m" 
echo "\033[32;1msekali lagi no recode"
echo "\033[32;1m[============================[>"
sleep 1
echo ""
echo "\033[32;1mMau pilih nomer yg mana:)?:"
echo "\033[36;1m"
echo "[===============================================[>"
echo $cyan "1.> gps tracking lacak orang"
echo $yellow "2.> musik youtube"
echo $cyan "3.> full bot fb"
echo $blue "4.> hack cctv"
echo $green "5.> metasploit"
echo $blue "6.> spam telepon"
echo $yellow "7.> spam wa"
echo $purple "8.> hack fb acak"
echo $cyan "0.> keluar"
echo "\033[32;1m"
read -p "[tulisnomernya:===>>>>" bro

if
[ $bro = 1 ] || [ $bro = 1 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
apt update
apt upgrade
apt install git
apt install python2
apt install php
git clone https://github.com/indosecid/IndoSecFramework
cd IndoSecFramework
unzip indosec.zip
php indosec.php
fi

if
[ $bro = 2 ] || [ $bro = 2 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
pip install mps_youtube
pip install youtube_dl
apt install mpv
mpsyt
fi

if
[ $bro = 3 ] || [ $bro = 3 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
apt update && apt upgrade
apt install python2
pip2 install requests mechanize
apt install git
git clone https://github.com/CiKu370/OSIF.git
cd OSIF
pip2 install -r requirements.txt
python2 osif.py
fi

if
[ $bro = 4 ] || [ $bro = 4 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
apt update && apt upgrade
pkg install python2
pkg install git
pip2 install requests
git clone https://github.com/kancotdiq/ipcs
cd ipcs
python2 scan.py
fi

if
[ $bro = 5 ] || [ $bro = 5 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
cd module
cd metasploit-framework-master
msfconsole
fi

if
[ $bro = 6 ] || [ $bro = 6 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
cd module
php call.php
fi

if
[ $bro = 7 ] || [ $bro = 7 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
cd module
php wa.php
fi

if
[ $bro = 8 ] || [ $bro = 8 ]
then
clear
toilet -f big -F gay "ZAIN" | 
lolcat
sleep 1
cd module
python2 MBF.py
fi

if [ $bro = 0 ] || [ $bro = 00 ]
then
echo "\033[32;1mAFNAN ZAINURI"
sleep 1
echo "\033[33;1mWE SOLO PLAYER"
sleep 1
echo " We ARSEUL COMUNITY"
sleep 1
echo "AKU KANGEN KAMU"
sleep 1
echo "KEMBALI LHA KEPADAKU"
sleep 1
echo "\033[32;1mKARNA SUATU HARI NANTI AKU AKAN MEMBAHAGIAKANMU:)"
sleep 1
exit
fi


